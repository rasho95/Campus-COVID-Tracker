package com.example.CampusCheckin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusCheckinApplicationTests {

	@Test
	void contextLoads() {
	}

}
